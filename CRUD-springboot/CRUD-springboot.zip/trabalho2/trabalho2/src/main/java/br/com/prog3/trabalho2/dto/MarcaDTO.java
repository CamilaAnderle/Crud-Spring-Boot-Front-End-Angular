package br.com.prog3.trabalho2.dto;

import br.com.prog3.trabalho2.domain.Marca;

public class MarcaDTO {
	private Integer id;
	private String sigla;
	private String descricao;
	
	public MarcaDTO(Integer id, String sigla, String descricao) {
		this.id = id;
		this.sigla = sigla;
		this.descricao = descricao;
	}

	public MarcaDTO(Marca marca) {
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
}
